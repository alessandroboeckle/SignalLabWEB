// Parser for "LOGDATA" measurement CSV files.
//
// Structure of these files:
//   SECTION;COMMON ... header sections ...
//   SECTION;LOGITEMS
//   LOGITEM;<signalName>;;<type>;<description with [unit: X]>;...
//   SECTION;LOGDATA
//   Nb;Type;Date;Time;<signal1>;<signal2>;...      <- column header
//   169503;+;07.03.2025;14:34:28:090;0;29.2;...     <- data rows
//
// Files are semicolon-separated and ISO-8859-1 encoded. The first 4 data
// columns are Nb / Type / Date / Time; signals start at column 5.

// Extract a unit from a LOGITEM description, mirroring the Python logic.
function extractUnit(text) {
  // 1. [unit: X]
  let m = text.match(/\[unit\s*:\s*([^\]]+)\]/i);
  if (m) return m[1].trim();
  // 2. (unit) anywhere
  m = text.match(/\(([^)]{1,20})\)/);
  if (m && m[1].trim()) return m[1].trim();
  // 3. [unit] in brackets — last resort. Real units (V, A, %, l/min, Nm, ...)
  // never contain whitespace; PLC I/O addresses often mistaken for units
  // here do (e.g. "[111/A92S1 DO 13]" is a hardware channel address, not
  // a unit) — skip anything with a space rather than plotting bogus units.
  const all = [...text.matchAll(/\[([^\]]{1,20})\]/g)];
  for (const bm of all) {
    const candidate = bm[1].trim();
    if (candidate && !/\s/.test(candidate)) return candidate;
  }
  return "";
}

// Look up a signal name in a LOGITEM-derived map (unitMap/typeMap), with a
// fallback for files where the LOGDATA header column carries a resource-node
// prefix that the LOGITEMS section does not (e.g. header
// "VCU_A.IIGB_A1_10.xFoo" vs. LOGITEM name "IIGB_A1_10.xFoo"). Without this,
// the lookup silently misses, BOOL columns get treated as REAL, and
// parseFloat("TRUE") produces NaN for every row.
function lookupWithPrefixFallback(map, name) {
  if (map[name] !== undefined) return map[name];
  let rest = name;
  let dot;
  while ((dot = rest.indexOf(".")) !== -1) {
    rest = rest.slice(dot + 1);
    if (map[rest] !== undefined) return map[rest];
  }
  return undefined;
}

// Convert a spreadsheet-style column reference to a 1-based index.
// Accepts plain numbers ("12") or letters ("A", "CC", ...).
export function colRefToNumber(ref) {
  if (ref === null || ref === undefined || ref === "") return null;
  const s = String(ref).trim();
  if (/^\d+$/.test(s)) return parseInt(s, 10);
  if (!/^[A-Za-z]+$/.test(s)) return null;
  let n = 0;
  const up = s.toUpperCase();
  for (let i = 0; i < up.length; i++) {
    n = n * 26 + (up.charCodeAt(i) - 64);
  }
  return n;
}

// Parse the raw text of a measurement CSV.
// options:
//   startRow, endRow   - 1-based range over the data rows to import (inclusive)
//   startCol, endCol   - 1-based range (or column-letter, e.g. "A"/"CC") over
//                        the signal columns (i.e. excluding Nb/Type/Date/Time)
//   sampleFrequenz     - if set, overrides the time axis with index/fs instead
//                        of the timestamps found in the file
// Returns { signals: [{name, unit, data:[numbers]}], time: [...], meta }.
export async function parseMesstoolCsv(text, options = {}) {
  const delimiter = ";";
  const lines = text.split(/\r?\n/);

  const startRow = options.startRow || null;
  const endRow = options.endRow || null;
  const startColNum = colRefToNumber(options.startCol);
  const endColNum = colRefToNumber(options.endCol);
  const sampleFrequenz =
    options.sampleFrequenz && options.sampleFrequenz > 0
      ? options.sampleFrequenz
      : null;

  // --- units + types from LOGITEM lines ---
  const unitMap = {};
  const typeMap = {};
  for (const raw of lines) {
    const line = raw.replace(/^\s+/, "");
    if (!line.startsWith("LOGITEM")) continue;
    const parts = line.split(delimiter).map((p) => p.trim());
    if (parts.length < 2) continue;
    const signalName = parts[1];
    const type = (parts[3] || "").toUpperCase();
    if (type) typeMap[signalName] = type;
    const desc = parts.slice(2).join(" ");
    const unit = extractUnit(desc);
    if (unit) unitMap[signalName] = unit;
  }

  // --- find the data header row (starts with "Nb") ---
  let headerIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    const cells = lines[i].split(delimiter);
    if (cells[0].trim() === "Nb") {
      headerIdx = i;
      break;
    }
  }
  if (headerIdx === -1) {
    throw new Error("Keine Datenzeile gefunden (kein 'Nb'-Header).");
  }

  const headerCells = lines[headerIdx].split(delimiter).map((c) => c.trim());
  // meta columns: Nb, Type, Date, Time -> signals from index 4 on
  const META_COLS = 4;
  const allSignalNames = headerCells.slice(META_COLS).filter((n) => n.length > 0);

  // apply optional column range (1-based, inclusive) over the signal columns
  const colFrom = startColNum ? Math.max(1, startColNum) - 1 : 0;
  const colTo = endColNum
    ? Math.min(allSignalNames.length, endColNum) - 1
    : allSignalNames.length - 1;
  const signalNames =
    colFrom > 0 || colTo < allSignalNames.length - 1
      ? allSignalNames.slice(colFrom, colTo + 1)
      : allSignalNames;

  // prepare containers
  const time = [];
  const clockSec = []; // real wall-clock time (seconds since midnight) per row, independent of whatever the x-axis uses
  const signalData = signalNames.map(() => []);
  const isBoolFlag = signalNames.map(
    (name) => lookupWithPrefixFallback(typeMap, name) === "BOOL"
  );

  // Optional progress reporting for large files: called with a 0..1
  // fraction every YIELD_EVERY rows, with a real (macro-task) yield after
  // each call so the browser can actually repaint a progress bar instead
  // of freezing for the whole parse.
  const onProgress = typeof options.onProgress === "function" ? options.onProgress : null;
  const YIELD_EVERY = 4000;
  const totalRows = Math.max(1, lines.length - headerIdx - 1);

  let t0 = null;
  let rowCounter = 0;

  for (let i = headerIdx + 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    const cells = line.split(delimiter);
    if (cells.length < META_COLS + 1) continue;

    rowCounter++;
    if (startRow && rowCounter < startRow) continue;
    if (endRow && rowCounter > endRow) break;

    // Time column is index 3, format HH:MM:SS:mmm
    const tSec = parseTimeToSeconds(cells[3]);
    if (t0 === null && tSec !== null) t0 = tSec;
    time.push(tSec !== null ? +(tSec - t0).toFixed(3) : time.length);
    clockSec.push(tSec);

    for (let s = 0; s < signalNames.length; s++) {
      const raw = cells[META_COLS + colFrom + s];
      const v = isBoolFlag[s] ? parseBoolValue(raw) : parseFloat(raw);
      signalData[s].push(Number.isFinite(v) ? v : null);
    }

    if (onProgress && rowCounter % YIELD_EVERY === 0) {
      onProgress(Math.min(0.99, rowCounter / totalRows));
      await new Promise((r) => setTimeout(r, 0));
    }
  }
  if (onProgress) onProgress(1);

  // Detect irregular sampling (gaps, jitter) from the timestamp-derived time
  // axis, before any samplefrequency override replaces it. Skipped when the
  // user already forces a samplefrequenz, since the axis is synthetic then.
  let sampleRateInfo = null;
  if (!sampleFrequenz && time.length > 2) {
    const dts = [];
    for (let i = 1; i < time.length; i++) dts.push(time[i] - time[i - 1]);
    const sorted = [...dts].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)] || 0;
    const detectedFs = median > 0 ? 1 / median : null;

    const gaps = [];
    if (median > 0) {
      for (let i = 0; i < dts.length; i++) {
        if (dts[i] > median * 1.5) {
          gaps.push({ atRow: i + 2, atTimeSec: +time[i + 1].toFixed(3), dt: +dts[i].toFixed(3) });
        }
      }
    }
    sampleRateInfo = {
      detectedFs: detectedFs ? +detectedFs.toFixed(3) : null,
      medianDt: +median.toFixed(6),
      gapCount: gaps.length,
      gaps: gaps.slice(0, 20), // cap so a pathological file doesn't blow up meta
    };
  }

  // optional samplefrequency override: replace the timestamp-derived time
  // axis with a plain index/fs grid (e.g. when timestamps are unreliable)
  if (sampleFrequenz) {
    for (let i = 0; i < time.length; i++) {
      time[i] = +(i / sampleFrequenz).toFixed(6);
    }
  }

  const signals = signalNames.map((name, idx) => ({
    name,
    unit: lookupWithPrefixFallback(unitMap, name) || "",
    type: lookupWithPrefixFallback(typeMap, name) || "",
    isBoolean: isBoolFlag[idx],
    data: signalData[idx],
  }));

  // Quality check: flag signals that carry no real information (nothing
  // but null, or a single constant value throughout) — a suspiciously
  // high share of these across the file can indicate a bad export from
  // the desktop tool (wrong channel mapping, truncated recording, etc.)
  // rather than genuinely inactive channels.
  const allNullSignals = [];
  const constantSignals = [];
  for (const s of signals) {
    let sawValue = false;
    let allSame = true;
    let firstVal = null;
    for (const v of s.data) {
      if (v == null) continue;
      sawValue = true;
      if (firstVal === null) firstVal = v;
      else if (v !== firstVal) { allSame = false; break; }
    }
    if (!sawValue) allNullSignals.push(s.name);
    else if (allSame) constantSignals.push(s.name);
  }
  const flaggedCount = allNullSignals.length + constantSignals.length;
  const qualityWarnings = signals.length
    ? {
        allNullSignals,
        constantSignals,
        // only worth surfacing if it's a large chunk of the file, not
        // just the odd genuinely-unused channel (e.g. Bogie B in the
        // brake-resistor recordings, which is normal)
        suspicious: flaggedCount / signals.length > 0.4,
      }
    : null;

  return {
    signals,
    time,
    clockSec,
    meta: {
      rowCount: time.length,
      signalCount: signals.length,
      duration: time.length ? time[time.length - 1] : 0,
      sampleRateInfo,
      qualityWarnings,
    },
  };
}

// BOOL-type LOGITEM columns store "TRUE"/"FALSE" (or German "WAHR"/"FALSCH")
// as text rather than a number — map them to 1/0 so they work like any
// other numeric signal in analysis/filter/processing. Anything else falls
// back to NaN, same as a failed parseFloat would.
function parseBoolValue(str) {
  if (str == null) return NaN;
  const s = str.trim().toUpperCase();
  if (s === "TRUE" || s === "WAHR" || s === "1") return 1;
  if (s === "FALSE" || s === "FALSCH" || s === "0") return 0;
  return NaN;
}

// "14:34:28:090" -> seconds since midnight (with millis)
function parseTimeToSeconds(str) {
  if (!str) return null;
  const p = str.trim().split(":");
  if (p.length < 3) return null;
  const h = parseInt(p[0], 10);
  const m = parseInt(p[1], 10);
  const s = parseInt(p[2], 10);
  const ms = p.length >= 4 ? parseInt(p[3], 10) : 0;
  if ([h, m, s].some((n) => Number.isNaN(n))) return null;
  return h * 3600 + m * 60 + s + (Number.isNaN(ms) ? 0 : ms / 1000);
}

// Inverse of parseTimeToSeconds: seconds-since-midnight -> "HH:MM:SS" (or
// with milliseconds if withMillis is set). Used to show the file's real
// clock time on a plot instead of just elapsed seconds.
export function formatClockTime(sec, withMillis = false) {
  if (sec == null || !Number.isFinite(sec)) return "-";
  let s = ((sec % 86400) + 86400) % 86400; // wrap safely, just in case
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const whole = Math.floor(s % 60);
  const ms = Math.round((s - Math.floor(s)) * 1000);
  const pad = (n, len = 2) => String(n).padStart(len, "0");
  const base = `${pad(h)}:${pad(m)}:${pad(whole)}`;
  return withMillis ? `${base}.${pad(ms, 3)}` : base;
}

// Decode an ArrayBuffer as ISO-8859-1 (latin1), which these files use.
export function decodeLatin1(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  let out = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    out += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return out;
}
