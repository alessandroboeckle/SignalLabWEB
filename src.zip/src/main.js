import { createApp } from "vue";
import { createPinia } from "pinia";
import "vuetify/styles";
import { createVuetify } from "vuetify";
import { aliases, mdi } from "vuetify/iconsets/mdi";
import * as Sentry from "@sentry/vue";

// Import MDI icon font (THIS makes icons visible!)
import "@mdi/font/css/materialdesignicons.css";

// Import global styles
import "./styles/global.css";

import App from "./App.vue";

const vuetify = createVuetify({
  // components/directives are no longer registered here — vite-plugin-vuetify's
  // autoImport (see vite.config.js) auto-imports only the components each
  // .vue file actually uses, instead of the full library.
  icons: {
    defaultSet: "mdi",
    aliases,
    sets: { mdi },
  },
  // Centralizes the "look" decisions that were otherwise being repeated
  // (or, in ~24 places, forgotten) per-component across every page —
  // Vuetify only falls back to these when a component doesn't set its
  // own prop explicitly, so nothing already-specified anywhere changes.
  defaults: {
    global: {
      // Material's classic all-caps button text reads dated now; every
      // modern interface (including Material 3 itself) uses sentence
      // case. Vuetify 3's CSS still forces uppercase by default.
      ripple: true,
    },
    VBtn: {
      class: "text-none",
      rounded: "lg",
    },
    VCard: { rounded: "lg" },
    VTextField: { variant: "outlined", density: "comfortable" },
    VSelect: { variant: "outlined", density: "comfortable" },
    VAutocomplete: { variant: "outlined", density: "comfortable" },
    VCombobox: { variant: "outlined", density: "comfortable" },
    VTextarea: { variant: "outlined", density: "comfortable" },
    VChip: { rounded: "lg" },
  },
  theme: {
    defaultTheme: "light",
    themes: {
      light: {
        dark: false,
        colors: {
          // Refined cyan/teal instead of generic Material blue — reads
          // closer to an instrument/scope readout than a stock SaaS
          // dashboard, and stays clearly distinct from the success green
          // and warning amber already used elsewhere.
          primary: "#0E7490",
          secondary: "#64748B",
          accent: "#FF6B35",
          error: "#EF4444",
          warning: "#F59E0B",
          info: "#3B82F6",
          success: "#10B981",
          background: "#F9FAFB",
          surface: "#FFFFFF",
        },
      },
      dark: {
        dark: true,
        colors: {
          primary: "#22D3EE",
          secondary: "#94A3B8",
          accent: "#FF6B35",
          error: "#F87171",
          warning: "#FBBF24",
          info: "#60A5FA",
          success: "#34D399",
          background: "#0B1220",
          surface: "#151F2E",
        },
      },
    },
  },
});

const app = createApp(App);
const pinia = createPinia();

// Error tracking — opt-in via VITE_SENTRY_DSN so local dev / anyone who
// hasn't set up a Sentry project still runs fine without it (see
// .env.example and README). Without this, errors thrown in a colleague's
// browser only ever land in their own console, never reaching us.
const sentryDsn = import.meta.env.VITE_SENTRY_DSN;
if (sentryDsn) {
  Sentry.init({
    app,
    dsn: sentryDsn,
    environment: import.meta.env.MODE,
  });
}

// Last-resort safety net: ErrorBoundary.vue catches and contains errors
// within whatever it wraps (shows a friendly fallback there). This global
// handler is for anything that somehow isn't caught by a boundary —
// reports it to Sentry (if configured) and logs it instead of leaving a
// silent blank page.
app.config.errorHandler = (err, instance, info) => {
  if (sentryDsn) Sentry.captureException(err, { extra: { info } });
  console.error("[Global error handler]", err, info);
};
window.addEventListener("unhandledrejection", (event) => {
  if (sentryDsn) Sentry.captureException(event.reason);
  console.error("[Unhandled promise rejection]", event.reason);
});

app.use(pinia);
app.use(vuetify);

app.mount("#app");
