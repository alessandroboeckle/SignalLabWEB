<template>
  <v-container fluid class="pa-4">
    <v-row>
      <v-col cols="12">
        <h2 class="text-h5 font-weight-bold mb-4">Dashboard</h2>
      </v-col>
    </v-row>

    <v-row>
      <!-- Statistics Cards -->
      <v-col cols="12" sm="6" md="3">
        <v-card class="elevation-2">
          <v-card-text>
            <div class="text-disabled text-caption mb-2">Sessions gesamt</div>
            <div class="text-h4 font-weight-bold">
              {{ store.allSessions.length }}
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card class="elevation-2">
          <v-card-text>
            <div class="text-disabled text-caption mb-2">Signale gesamt</div>
            <div class="text-h4 font-weight-bold">{{ totalSignals }}</div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card class="elevation-2">
          <v-card-text>
            <div class="text-disabled text-caption mb-2">Aktuelle Session</div>
            <div class="text-h6 font-weight-bold text-truncate">
              {{ store.currentSession.name }}
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card class="elevation-2">
          <v-card-text>
            <div class="text-disabled text-caption mb-2">Speichernutzung</div>
            <div class="text-h6 font-weight-bold">
              {{ storageInfo.storageUsage }}
            </div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <v-row class="mt-4">
      <v-col cols="12">
        <v-card class="elevation-2" color="primary" variant="tonal">
          <v-card-text class="d-flex align-center flex-wrap ga-4">
            <div class="flex-grow-1">
              <div class="text-h6 font-weight-bold mb-1">
                <v-icon class="mr-1">mdi-chart-bell-curve</v-icon>
                Messtool
              </div>
              <div class="text-body-2 text-medium-emphasis">
                Messdaten (LOGDATA-CSV oder Excel) laden, filtern, analysieren und vergleichen.
              </div>
            </div>
            <v-btn color="primary" prepend-icon="mdi-file-upload" @click="emit('navigate', 'mt-import')">
              Messdatei laden
            </v-btn>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <v-row class="mt-4">
      <v-col cols="12" md="6">
        <v-card class="elevation-2">
          <v-card-title>Letzte Signale</v-card-title>
          <v-card-text>
            <v-list v-if="recentSignals.length > 0" density="compact">
              <v-list-item v-for="signal in recentSignals" :key="signal.id">
                <template v-slot:prepend>
                  <v-icon small color="primary">mdi-sine-wave</v-icon>
                </template>
                <v-list-item-title>{{ signal.name }}</v-list-item-title>
                <v-list-item-subtitle>
                  {{ signal.waveType }} @ {{ signal.frequency }}Hz
                </v-list-item-subtitle>
                <template v-slot:append>
                  <v-btn icon size="small" @click="loadSignal(signal.id)">
                    <v-icon small>mdi-eye</v-icon>
                  </v-btn>
                </template>
              </v-list-item>
            </v-list>
            <div v-else class="text-center text-disabled py-4">
              Noch keine Signale. Erstelle eins, um loszulegen!
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" md="6">
        <v-card class="elevation-2">
          <v-card-title>Generator-Tool — Schnellzugriff</v-card-title>
          <v-card-text>
            <v-btn class="mb-2 w-100" color="primary" prepend-icon="mdi-plus" @click="quickNewSession">
              Neue Session
            </v-btn>
            <v-btn
              class="mb-2 w-100"
              color="primary"
              variant="outlined"
              prepend-icon="mdi-sine-wave"
              @click="emit('navigate', 'signal')"
            >
              Signal generieren
            </v-btn>
            <v-btn
              class="mb-2 w-100"
              color="primary"
              variant="outlined"
              prepend-icon="mdi-download"
              @click="emit('navigate', 'settings')"
            >
              Daten exportieren
            </v-btn>
            <v-btn
              class="w-100"
              color="primary"
              variant="outlined"
              prepend-icon="mdi-delete"
              @click="emit('navigate', 'settings')"
            >
              Alles löschen
            </v-btn>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <!-- Last Generated Signal Preview -->
    <v-row v-if="store.currentSignal.timeData.length > 0" class="mt-4">
      <v-col cols="12">
        <v-card class="elevation-2">
          <v-card-title>Signal-Vorschau</v-card-title>
          <v-card-text>
            <canvas id="previewChart"></canvas>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { computed, onMounted, watch, nextTick } from "vue";
import { useSignalStore } from "../stores/signalStore";
import * as storage from "../utils/storage.js";
import Chart from "../utils/chartSetup.js";

const store = useSignalStore();
let chart = null;

const emit = defineEmits(["navigate"]);

async function quickNewSession() {
  try {
    await store.createSession("Neue Session");
    emit("navigate", "sessions");
  } catch (e) {
    console.error("New session failed:", e);
  }
}

const totalSignals = computed(() => {
  return store.allSessions.reduce((sum, session) => {
    return sum + storage.loadSessionSignals(session.id).length;
  }, 0);
});

const storageInfo = computed(() => {
  return storage.getStorageInfo();
});

const recentSignals = computed(() => {
  return store.currentSession.signals.slice(-5).reverse();
});

function loadSignal(signalId) {
  store.loadSignal(signalId);
}

function drawChart() {
  const canvas = document.getElementById("previewChart");
  if (!canvas) return;

  if (chart) {
    chart.destroy();
  }

  const signal = store.currentSignal;
  if (signal.timeData.length === 0) return;

  // Sample data for display (max 1000 points)
  const sampleRate = Math.ceil(signal.timeData.length / 1000);
  const sampledTime = signal.timeData.filter((_, i) => i % sampleRate === 0);
  const sampledAmplitude = signal.amplitudeData.filter(
    (_, i) => i % sampleRate === 0,
  );

  chart = new Chart(canvas, {
    type: "line",
    data: {
      labels: sampledTime.map((t) => t.toFixed(3)),
      datasets: [
        {
          label: signal.name,
          data: sampledAmplitude,
          borderColor: "#2563EB",
          backgroundColor: "rgba(37, 99, 235, 0.1)",
          borderWidth: 2,
          pointRadius: 0,
          tension: 0.4,
          fill: true,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          display: true,
          labels: {
            usePointStyle: true,
            padding: 15,
          },
        },
      },
      scales: {
        y: {
          grid: {
            color: "rgba(0, 0, 0, 0.1)",
          },
        },
        x: {
          grid: {
            display: false,
          },
        },
      },
    },
  });
}

onMounted(() => {
  drawChart();
});

watch(
  () => store.currentSignal.timeData.length,
  async () => {
    await nextTick(); // canvas only exists once v-if="...length > 0" has rendered
    drawChart();
  },
);
</script>

<style scoped>
canvas {
  max-height: 400px;
}
</style>
